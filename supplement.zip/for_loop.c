#include <stdio.h>

int main()
{
	int index;
	
	for (index = 0; index < 10; index = index + 1)
	{
		printf("%d\n", index);
	}

	return 0;
}


