#include <stdio.h>

struct location
{
	float x;
	float y;
};

int main()
{
	struct location A;

	A.x = 1.0;
	A.y = 3.0;

	return 0;
}
