#include <stdio.h>

// argument 引數 變數
int main(int argc, char *argv[])
{
	int i;
	printf("%d\n", argc);	
	for (i = 0; i < argc; i++)
	{
		printf("%s\n", argv[i]);	
	}
	return 8; // resulting $? in OS
}
